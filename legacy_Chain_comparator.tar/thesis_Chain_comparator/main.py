"""
Written by: David S. Weber -

This script determines bridge/aromatic chain superimposability.
(1) We import a structure
(2) We find Met-aromatic interactions 
(3) From Met-aromatic interactions we find 2-bridges
(4) We then find closely spaced Tyr/Trp residues
(5) We apply network theory approaches to determine superimposability
"""

PDB_CODE = '3lhs'  # input the PDB code of interest
D_C = 6.0  # this is the distance cutoff for the distance condition (2.3)
A_C = 109.5  # this is the angular cutoff for the angular condition (2.4)


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# dependencies

import sys
import Bio.PDB as bp
import os
import pandas as pd
import numpy as np
import networkx as nx
import _functions_MetAromatic as ma
import _functions_Membership as me  # TODO: unused old functions? replaced with NetworkX?
import _functions_NearestNeighbours as nn

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# constants and other hard coding 

STRUCT = 0
CHAIN = 'A'
CUTOFF = 7.4  # for aromatic chains
ATOMS_MET = 'CE|SD|CG'  # see line 10: Algorithm 1 Met-aromatic
ATOMS_TYR = 'CD1|CE1|CZ|CG|CD2|CE2'   # see line 12: Algorithm 1 Met-aromatic
ATOMS_TRP = 'CD2|CE3|CZ2|CH2|CZ3|CE2'  # see line 14: Algorithm 1 Met-aromatic
ATOMS_PHE = 'CD1|CE1|CZ|CG|CD2|CE2'   # see line 12: Algorithm 1 Met-aromatic
LIST_ATOMS_TYR = ['CG', 'CD2', 'CE2', 'CZ', 'CE1', 'CD1']
LIST_ATOMS_TRP = ['CD2', 'CE3', 'CZ3', 'CH2', 'CZ2', 'CE2']
LIST_ATOMS_PHE = ['CG', 'CD2', 'CE2', 'CZ', 'CE1', 'CD1']
LIST_ATOMS_MET = ['CG', 'SD', 'CE']
TAGS = ['A', 'B', 'C', 'D', 'E', 'F']

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# function and class definitions

def res_segid(residue_input):
    # a workaround function for BioPython's get_segid() issue
    res_string = str(residue_input)
    resseq = res_string.find('resseq=') + 7
    return float(res_string[resseq:].split(' ')[0])
    
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# get data from Protein Data Bank

"""
We begin by importing the data of interest using BioPython. BioPython
has decent routines for connecting to the PDB and subsequently importing
the data of interest. I personally don't like BioPython for anything other
than importing and isolating PDB data so I use Pandas for all downstream work.
"""       

# create a biopython parser object
# QUIET=True suppresses 'WARNING: Chain [] is discontinuous at line...'
parser = bp.PDBParser(QUIET=True) 
pdbl = bp.PDBList(verbose=False)

# occasional issue with some PDB codes being decoded as numbers
try:
    path_to_file = pdbl.retrieve_pdb_file(pdb_code=PDB_CODE, file_format="pdb", pdir=os.getcwd())
except Exception as exception:
    sys.exit(exception)
else:
    structure = parser.get_structure('mystring', path_to_file)

# remove PDB file once we get structure
if os.path.exists(path_to_file):
    os.remove(path_to_file)     


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# get bridging interactions and aromatic chains

"""
I use BioPython to isolate PDB data down to the RA level (in SMCRA). 
The RA level is then further sorted using Pandas which is my 
preferred data analysis package.
"""                              

# isolate data of interest
model = structure[STRUCT]
chain = model[CHAIN]

# iteratively sort and arrange data for dataframe
to_df = []
for atoms in bp.Selection.unfold_entities(chain, 'A'):
    res_obj = atoms.get_parent()
    xyz = atoms.get_coord()
    to_df.append([chain.id, res_segid(res_obj), res_obj.get_resname(), atoms.name, xyz[0], xyz[1], xyz[2]])
                      
# cast to dataframe
df = pd.DataFrame(to_df)
df.columns = ['CHAIN', 'RES', 'RES NAME', 'ATOM', 'x', 'y', 'z']  

"""
This block is a vectorized equivalent of lines 1-5 in 
Algorithm 1 Met-aromatic. Here we isolate down to only those residues
of interest to us.
"""

# isolate down to residues we are interested in
df_MET = df[df['RES NAME'] == 'MET']
df_TYR = df[df['RES NAME'] == 'TYR']
df_TRP = df[df['RES NAME'] == 'TRP']  
df_PHE = df[df['RES NAME'] == 'PHE']     

# exit if there are no Met residues
if df_MET.empty:
    sys.exit('No methionine residues in protein.')

# exit if there's Phe, Tyr or Trp residues
if all([df_TYR.empty, df_TRP.empty, df_PHE.empty]):
    sys.exit('No Phe, Tyr or Trp residues in protein.')

"""
This block is a vectorized equivalent of lines 7-15 in
Algorithm 1 Met-aromatic. We strip down to only atoms of interest to us.
In this block we also order our data by tags in preparation for midpoint
calculations. This was not mentioned in Algorithm 1 Met-aromatic.
"""
           
# isolate down to atoms in the residues
df_MET = df_MET[df_MET['ATOM'].str.contains(ATOMS_MET)]
df_TYR = df_TYR[df_TYR['ATOM'].str.contains(ATOMS_TYR)]
df_TRP = df_TRP[df_TRP['ATOM'].str.contains(ATOMS_TRP)]
df_PHE = df_PHE[df_PHE['ATOM'].str.contains(ATOMS_PHE)]

# tag all atoms
df_MET['TAGS'] = df_MET['ATOM'].replace(LIST_ATOMS_MET, TAGS[0:3])
df_PHE['TAGS'] = df_PHE['ATOM'].replace(LIST_ATOMS_PHE, TAGS)
df_TYR['TAGS'] = df_TYR['ATOM'].replace(LIST_ATOMS_TYR, TAGS)
df_TRP['TAGS'] = df_TRP['ATOM'].replace(LIST_ATOMS_TRP, TAGS)

# sort atoms in preparation for midpoint calculation
df_MET = df_MET.sort_values(by='TAGS')
df_PHE = df_PHE.sort_values(by='TAGS')
df_TYR = df_TYR.sort_values(by='TAGS')
df_TRP = df_TRP.sort_values(by='TAGS')

# group by residue number
df_MET_GB = df_MET.groupby('RES')
df_PHE_GB = df_PHE.groupby('RES')
df_TYR_GB = df_TYR.groupby('RES')
df_TRP_GB = df_TRP.groupby('RES')

# first get all midpoints
midpoints_PHE = pd.DataFrame()
midpoints_TYR = pd.DataFrame()
midpoints_TRP = pd.DataFrame()

"""
Split / apply / combine procedure for computing hexagon midpoints. The df.append()
procedure, in general, is not recommended. However there are very few dfs to
append at this stage in the program and the df.append() function here has little
additional computational costs relative to other methods available.
"""

for residue_key, groupby_obj in df_PHE_GB:
    x_list = groupby_obj['x'].tolist()
    y_list = groupby_obj['y'].tolist()
    z_list = groupby_obj['z'].tolist()
    x_mid, y_mid, z_mid = ma.get_hexagon_midpoints(x_list, y_list, z_list)
    dfs = pd.DataFrame([[residue_key] * 6, x_mid, y_mid, z_mid]).transpose()
    midpoints_PHE = midpoints_PHE.append(dfs)
    
for residue_key, groupby_obj in df_TYR_GB:
    x_list = groupby_obj['x'].tolist()
    y_list = groupby_obj['y'].tolist()
    z_list = groupby_obj['z'].tolist()
    x_mid, y_mid, z_mid = ma.get_hexagon_midpoints(x_list, y_list, z_list)
    dfs = pd.DataFrame([[residue_key] * 6, x_mid, y_mid, z_mid]).transpose()
    midpoints_TYR = midpoints_TYR.append(dfs)

for residue_key, groupby_obj in df_TRP_GB:
    x_list = groupby_obj['x'].tolist()
    y_list = groupby_obj['y'].tolist()
    z_list = groupby_obj['z'].tolist()
    x_mid, y_mid, z_mid = ma.get_hexagon_midpoints(x_list, y_list, z_list)
    dfs = pd.DataFrame([[residue_key] * 6, x_mid, y_mid, z_mid]).transpose()
    midpoints_TRP = midpoints_TRP.append(dfs)
    
# stack all midpoint dataframes
PHE_label = pd.DataFrame(midpoints_PHE.shape[0] * ['PHE'])
TYR_label = pd.DataFrame(midpoints_TYR.shape[0] * ['TYR'])
TRP_label = pd.DataFrame(midpoints_TRP.shape[0] * ['TRP'])

midpoints_PHE = midpoints_PHE.reset_index(drop=True)
midpoints_TYR = midpoints_TYR.reset_index(drop=True)
midpoints_TRP = midpoints_TRP.reset_index(drop=True)

midpoints_PHE = pd.concat([midpoints_PHE, PHE_label], axis=1)
midpoints_TYR = pd.concat([midpoints_TYR, TYR_label], axis=1)
midpoints_TRP = pd.concat([midpoints_TRP, TRP_label], axis=1)

midpoints_ALL = pd.concat([midpoints_PHE, midpoints_TYR, midpoints_TRP], axis=0)
midpoints_ALL = midpoints_ALL.reset_index(drop=True)
midpoints_ALL.columns = ['RES', 'x', 'y', 'z', 'ARO']

"""
Here we apply the lowest level of the Met-aromatic algorithm to our
refined feature space F. This corresponds to lines 17-26 in
Algorithm 1 Met-aromatic. Again, this is highly vectorized and does not
perfectly match the algorthm in the thesis.
"""

df_cp = pd.DataFrame()

for res_key, met_res in df_MET.groupby('RES'):
    # first get CE, SD and CG coordinates
    CE, SD, CG = met_res.values[:, 4:7].astype(float)
    
    # then map all midpoints to origin of SD to get vectors v
    aro_res = pd.DataFrame()
    aro_res[['v_x', 'v_y', 'v_z']] = midpoints_ALL[['x', 'y', 'z']] - SD
    aro_res['RES'] = midpoints_ALL[['RES']].astype(int)
    aro_res['ARO'] = midpoints_ALL[['ARO']]
                 
    # then get norm of mapped vectors v
    aro_res['NORM'] = np.sqrt(np.square(aro_res[['v_x', 'v_y', 'v_z']]).sum(axis=1))
   
    # then apply distance condition & bank anything below cutoff
    aro_res = aro_res[aro_res['NORM'] <= D_C]
    
    # continue here to next iteration if aro_res is empty
    if aro_res.empty:
        continue
    else:
        pass
    
    # get lone pairs using cross product method approach
    lp_object = ma.LonePairs(CE, SD, CG)
    vec_a_cp = lp_object.vector_a()
    vec_g_cp = lp_object.vector_g()
    
    aro_res['a_x_cp'] = vec_a_cp[0]
    aro_res['a_y_cp'] = vec_a_cp[1]
    aro_res['a_z_cp'] = vec_a_cp[2]
    
    aro_res['g_x_cp'] = vec_g_cp[0]
    aro_res['g_y_cp'] = vec_g_cp[1]
    aro_res['g_z_cp'] = vec_g_cp[2]
    
    aro_res['MET-THETA-CP'] = aro_res.apply(ma.angle_met_theta_cp, axis=1)
    aro_res['MET-PHI-CP'] = aro_res.apply(ma.angle_met_phi_cp, axis=1)
    
    # now apply angular condition & bank anything meeting condition
    aro_res_cp = aro_res[(aro_res['MET-THETA-CP'] <= A_C) | (aro_res['MET-PHI-CP'] <= A_C)]
    
    # relabel and add MET column
    aro_res_cp = aro_res_cp[['ARO', 'RES', 'NORM', 'MET-THETA-CP', 'MET-PHI-CP']]  
    aro_res_cp['MET'] = int(res_key)
        
    # continue here to next iteration if aro_res_cp is empty
    if aro_res_cp.empty:
        continue
    else:
        df_cp = df_cp.append(aro_res_cp)
    
   
# exit if we have no Met-aromatic interactions
if df_cp.empty:
    sys.exit('No Met-aromatic interactions.')

# now find bridging interactions
df_cp = df_cp.reset_index(drop=True)
cp_brdg = df_cp[['ARO', 'RES', 'MET']].drop_duplicates()
cp_brdg['BRDG'] = cp_brdg.groupby('MET', as_index=False)['MET'].transform(lambda s: s.count())

# ensure that we have only 2-bridges / this can be modified to find n-bridges
cp_brdg = cp_brdg[cp_brdg.BRDG == 2]

# exit if we have no 2-bridges
if cp_brdg.empty:
    sys.exit('No 2-bridges.')

# now find closely spaced aromatic residues
    
# isolate down to edges of an aromatic ring
df_TYR = df_TYR[df_TYR['ATOM'].str.contains('CG|CZ')]
df_TRP = df_TRP[df_TRP['ATOM'].str.contains('CD2|CH2')]
    
# compute centroids
centroid_TYR = df_TYR.groupby('RES')[['x', 'y', 'z']].mean()
centroid_TRP = df_TRP.groupby('RES')[['x', 'y', 'z']].mean()

# label dfs
centroid_TYR['ARO'] = ['TYR'] * centroid_TYR.shape[0]
centroid_TRP['ARO'] = ['TRP'] * centroid_TRP.shape[0]

# reset indices
centroid_TYR = centroid_TYR.reset_index()
centroid_TRP = centroid_TRP.reset_index()

# merge
centroids = np.concatenate((centroid_TYR.values, centroid_TRP.values))

# use modified nearest neighbours function for getting nearest neighbours
neighbours = nn.get_nearest_neighbors(centroids, CUTOFF) 

# check if neighbours exist
if neighbours == []:
    sys.exit('File contains no chains.')

# format neighbours array
neighbours = [np.concatenate((item[0], item[1])) for item in neighbours]

# send to df
df_neighbours = pd.DataFrame(neighbours)
df_neighbours.columns = ['RES_A', 'x', 'y', 'z', 'ARO_A', 'RES_B', 'x', 'y', 'z', 'ARO_B']

"""
Now we have our bridges for both the cross product (cp) lone pair tetrahedron models. 
We also have our aromatic chains in df_neighbours. We can now determine whether 
bridging interactions superimpose with aromatic chains. We use the NetworkX 
library for working with this data.
"""

# get the first edge list - aromatic chains
edge_a = df_neighbours['RES_A'].tolist()
edge_b = df_neighbours['RES_B'].tolist()

# get the second edge list - bridging interactions
# get the edge lists for only Tyr/Trp bridges for cross product model
edge_c_cp = []
edge_d_cp = []
for _, rows in cp_brdg.groupby('MET'):
    if rows.iloc[0, 0] in ['TYR', 'TRP'] and rows.iloc[1, 0] in ['TYR', 'TRP']:    
        edge_c_cp.append(rows.iloc[0, 1])    
        edge_d_cp.append(rows.iloc[1, 1])
        
# exit if we have no sole Tyr/Trp bridges
if edge_c_cp == [] and edge_d_cp == []:
    sys.exit('CP: No Tyr/Trp::Met::Tyr/Trp bridges.')        

# generate two undirected graphs
G1 = nx.Graph()  # aromatic chains
G2 = nx.Graph()  # bridging interactions

# add aromatic chain nodes
nodes_G1 = list(set(edge_a + edge_b))
G1.add_nodes_from(nodes_G1)

# generate edge lists and add to G1
edges_G1 = [(a, b) for a, b in zip(edge_a, edge_b)]
G1.add_edges_from(edges_G1)

# add bridging interaction nodes
nodes_G2 = list(set(edge_c_cp + edge_d_cp))
G2.add_nodes_from(nodes_G2)

# generate edge lists and add to G2
edges_G2 = [(a, b) for a, b in zip(edge_c_cp, edge_d_cp)]
G2.add_edges_from(edges_G2)

# get disconnected components by getting nullity of graph Laplacian matrix
G1_disconnected = list(nx.connected_components(G1))  # chains
G2_disconnected = list(nx.connected_components(G2))  # bridges              

# beautiful, syntactic Python logic
for chain in G1_disconnected:
    for bridge in G2_disconnected:    
        if chain & bridge == set():  # condition 1
            print('1: No relationship between chain {} and bridge {}'.format(chain, bridge))
        elif chain - bridge == set():   # condition 2
            print('2: Bridge {} collapses to 2-chain {}'.format(bridge, chain))
        elif chain & bridge == bridge:  # condition 3
            print('3: Bridge {} member of larger chain {}'.format(bridge, chain))
        elif next(iter(chain & bridge)) in bridge:  # condition 4
            print('4: One residue of bridge {} in larger chain {}'.format(bridge, chain))
        else:
            print('Who knows...')
            
            