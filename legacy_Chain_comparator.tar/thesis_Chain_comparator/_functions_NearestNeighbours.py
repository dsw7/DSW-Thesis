# Written by David S. Weber / dsw7@sfu.ca
# All functions needed for finding closely spaced chains

import numpy as np

def range_2d_iter(iterator_A, iterator_B):
    # generator for flattening 2-nests into a single loop
    for A in iterator_A:
        for B in iterator_B:
            yield A, B

def get_nearest_neighbors(input_list, cutoff_value):
    """
    A custom function for computing nearest neighbors for coords in a list.
    Params:
        input_list   -> a list like object we iterate over
        cutoff_value -> float dtype distance between two coordinates
                        that we consider neighboring
                        
    * Important *
    The indices in:
        norm = np.linalg.norm(_iter_a[1:4] - _iter_b[1:4]) 
    Need to be changed depending on the dataframe/array being passed as arg.                  
    """
    output_A = []
    for _iter_a, _iter_b in range_2d_iter(input_list, input_list):
        if _iter_a[1] != _iter_b[1]:  # delete self-coupling
            norm = np.linalg.norm(_iter_a[1:4] - _iter_b[1:4])
            if norm <= cutoff_value:
                output_A.append([_iter_a, _iter_b, norm])
                
    """
    And we have to remove duplicates:
    i.e. res 115 / res 163 distance && res 163 / res 115 distance
    """
    seen = set()
    output_B = [x for x in output_A if x[2] not in seen and not seen.add(x[2])]
    output_C = [x[0:2] for x in output_B]  # strip out norms
    return output_C