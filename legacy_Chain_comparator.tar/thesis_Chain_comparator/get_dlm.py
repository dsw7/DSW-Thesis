# a script written for getting the dlm.csv delimiter list
# the dlm.csv data is obtained from files previously known to contain
# both aromatic chains and bridging interactions

import os
import pandas as pd

# root = r'/Volumes/MSC/DATABASES/2018 Bridging Databases'
root = r'G:/DATABASES/2018 Bridging Databases'

# first path: path to aromatic chain data
path = os.path.join(root, 'AromaticChainsData_compressed.csv')
df_AROC = pd.read_csv(path)
df_AROC = df_AROC.drop('Unnamed: 0', axis=1)

# second path: path to geometric data
path2 = os.path.join(root, 'GeometricData_compressed.csv')
df_GEOM = pd.read_csv(path2)
df_GEOM = df_GEOM.drop('Unnamed: 0', axis=1)

"""
So now we have imported two data sets:
    (1) Data that corresponds solely to Tyr and Trp chains.
    (2) Data that we know contains both bridging interactions & metals.
    
    (1) -> ~/AromaticChainsData_compressed.csv
    (2) -> ~/GeometricData_compressed.csv

Next we need to compare the data. We need to determine whether bridges in the
geometric data set are also contained in long range aromatic chains in the chains
data set.
"""

# remove all PHE containing bridges
df_GEOM = df_GEOM[(df_GEOM['ARO A'] != 'PHE') & (df_GEOM['ARO B'] != 'PHE')]

# cast all codes to lists
df_AROC_codes = list(set(df_AROC['PDB CODE'].tolist()))
df_GEOM_codes = list(set(df_GEOM['PDB CODE'].tolist()))

# pool everything
all_codes = list(set(df_GEOM_codes + df_AROC_codes))

# generate a list of codes mutually present in both dfs
mutual = [i for i in all_codes if i in df_AROC_codes and i in df_GEOM_codes]  # len = 2611
# generate a list of codes that are not present in both dfs
exclud = [i for i in all_codes if i not in df_AROC_codes or i not in df_GEOM_codes]

# confirm data is not being lost
if len(mutual) + len(exclud) != len(all_codes):
    print('Data is being lost.')
else:
    pd.DataFrame(mutual).to_csv('dlm.csv')
