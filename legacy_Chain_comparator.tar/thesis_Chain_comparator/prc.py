# script used for processing all output in ~/output folder

import pandas as pd
import os
import matplotlib.pyplot as plt

# import all files
paths = os.listdir('output')

frame = pd.DataFrame()
cat_df = []

for file in paths:
    df_in = pd.read_csv(os.path.join('output', file))
    df_in['CODE'] = file[0:4]
    cat_df.append(df_in)
    
frame = pd.concat(cat_df)
frame = frame.drop('Unnamed: 0', axis=1)
frame = frame.reset_index(drop=True)

# find individual codes
frame_codes = frame.DESCRIPTION.str.split(':', expand=True)[0]
frame_codes = frame_codes.astype(float)
list_codes = frame_codes.tolist()

# geometry counts
counts = [list_codes.count(float(i)) for i in range(1, 5)]

# plot
labels = ['A', 'B', 'C', 'D']

# 1 : A : No relationship between chain {} and bridge {}
# 2 : B : Bridge {} collapses to 2-chain {}
# 3 : C : Direct superimposition - Bridge {} member of larger chain {}
# 4 : D : Indirect Superimposition - One residue of bridge {} in larger chain {}

plt.rcParams['text.usetex'] = True
fig, ax = plt.subplots(figsize=(2.5, 5))  # units in inches
ind = list(range(1, 5))
plt.bar(ind, counts, edgecolor='k', width=0.5, facecolor='r')
ax.set_xticks(ind)
ax.set_xticklabels(labels, size=25)
ax.tick_params(direction='out', length=6, width=2, labelsize=25)
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
ax.set_ylim([0, 13000])
ax.set_ylabel('Frequency', size=25)
ax.yaxis.set_ticklabels([])
ax.yaxis.set_ticks([])

OFFSET = 0.05  # very slight bar label offset

# add some bar labels
plt.text(1.00 + OFFSET, counts[0] + 100, counts[0], rotation='vertical', size=20, va='bottom', ha='center')
plt.text(2.00 + OFFSET, counts[1] + 100, counts[1], rotation='vertical', size=20, va='bottom', ha='center')
plt.text(3.00 + OFFSET, counts[2] + 100, counts[2], rotation='vertical', size=20, va='bottom', ha='center')
plt.text(4.00 + OFFSET, counts[3] + 100, counts[3], rotation='vertical', size=20, va='bottom', ha='center')

plt.savefig('fig8LEFT.png', dpi=700, bbox_inches='tight')