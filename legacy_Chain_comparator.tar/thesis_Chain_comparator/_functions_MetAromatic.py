# Written by David S. Weber / dsw7@sfu.ca
# All functions needed for Met-aromatic algorithm

import numpy as np

SCAL1 = np.sin(np.pi / 2)
SCAL2 = 1 - np.cos(np.pi / 2)

def vector_angle(u, v):
    # a routine for computing angle between two vectors
    num = np.dot(u, v)
    den = np.linalg.norm(v) * np.linalg.norm(u)
    return np.degrees(np.arccos(num / den))

def unit_vec(v):
    # get the unit vector of a vector
    return v / np.linalg.norm(v)
    
def angle_met_theta_rm(row):
    # df compatible routine for finding met-theta angle
    a = np.array([row['a_x_rm'], row['a_y_rm'], row['a_z_rm']])
    v = np.array([row['v_x'], row['v_y'], row['v_z']])
    return vector_angle(a, v)
    
def angle_met_phi_rm(row):
    # df compatible routine for finding met-phi angle
    g = np.array([row['g_x_rm'], row['g_y_rm'], row['g_z_rm']])
    v = np.array([row['v_x'], row['v_y'], row['v_z']])
    return vector_angle(g, v)
    
def angle_met_theta_cp(row):
    # df compatible routine for finding met-theta angle
    a = np.array([row['a_x_cp'], row['a_y_cp'], row['a_z_cp']])
    v = np.array([row['v_x'], row['v_y'], row['v_z']])
    return vector_angle(a, v)
    
def angle_met_phi_cp(row):
    # df compatible routine for finding met-phi angle
    g = np.array([row['g_x_cp'], row['g_y_cp'], row['g_z_cp']])
    v = np.array([row['v_x'], row['v_y'], row['v_z']])
    return vector_angle(g, v)

def get_hexagon_midpoints(x, y, z):
    """
    Function for computing midpoints between vertices in a hexagon
    Parameters:
        x, y, z -> list objects of x, y, and z hexagon coordinates
    Returns:
        x_mid, y_mid, z_mid -> a list of x, y, and z hexagon midpoint coordinates
    """
    
    # offset each list by 1
    x_f = x[1:] + [x[0]]
    y_f = y[1:] + [y[0]]
    z_f = z[1:] + [z[0]]

    # compute means between original and offset lists
    x_mid = [0.5 * (a + b) for a, b in zip(x, x_f)]
    y_mid = [0.5 * (a + b) for a, b in zip(y, y_f)]
    z_mid = [0.5 * (a + b) for a, b in zip(z, z_f)]
    
    return x_mid, y_mid, z_mid

class RodriguesMethod:
    """
    Here I use Rodrigues' rotation formula for completing the vertices
    of a regular tetrahedron. To start, we know two vertices of a tetrahedron,
    A and B, in addition to knowing the origin O. So we map A and B to the
    origin of the frame in which the tetrahedron resides by computing
    u = A - O and v = B - O. The directions of u, v are then flipped by scaling
    u, v by -1. We then take -u, -v and rotate the vectors by 90 degrees about
    k, where k is the line of intersection between the two orthogonal planes
    of the tetrahedron. These rotated vectors now describe the position of the
    remaining coordinates C, D. We have our tetrahedron with vertices A, B,
    C, D and the origin O.
    """
    def __init__(self, vertex_a, origin, vertex_b):
        # map to origin
        vec_u = vertex_a - origin
        vec_v = vertex_b - origin
        
        # flip direction
        self.vec_u = -1 * vec_u
        self.vec_v = -1 * vec_v
        
        # we then find the vector about which we rotate
        r = 0.5 * (self.vec_u + self.vec_v)
        
        # then find unit vector of r
        r_hat = r / np.linalg.norm(r)
        
        # get components of the unit vector r
        r_hat_x = r_hat[0]
        r_hat_y = r_hat[1]
        r_hat_z = r_hat[2]
        
        # get the W matrix
        W = np.matrix([[0, -r_hat_z, r_hat_y],
                       [r_hat_z, 0, -r_hat_x],
                       [-r_hat_y, r_hat_x, 0]])
                       
        # then construct Rodrigues rotation matrix
        self.R = np.matrix(np.eye(3)) + (SCAL1 * W) + (SCAL2 * np.matmul(W, W))
    
    # note that I flipped these methods to match previous algorithm
    def vector_g(self):
        # get vector g - first vertex
        return np.matmul(self.R, self.vec_u)

    def vector_a(self):
        # get vector v - second vertex
        return np.matmul(self.R, self.vec_v)

class LonePairs:
    # a class for computing the vectors parallel to MET SD lone pairs
    # methods associated with the class complete the vertices of a tetrahedron
    def __init__(self, terminal_a, midpoint, terminal_b):
        self.terminal_a = terminal_a
        self.midpoint = midpoint
        self.terminal_b = terminal_b
        self.u = self.terminal_a - self.midpoint # mapping to origin
        self.v = self.terminal_b - self.midpoint # mapping to origin
        self.NOT_vec = unit_vec(-0.5 * (unit_vec(self.v) + unit_vec(self.u)))
        
    def vector_a(self):
        cross_vec = np.cross(self.u, self.v)
        return self.NOT_vec + 2**0.5 * unit_vec(cross_vec)
        
    def vector_g(self):
        cross_vec = np.cross(self.v, self.u)
        return self.NOT_vec + 2**0.5 * unit_vec(cross_vec)