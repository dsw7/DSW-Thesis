# Written by David S. Weber / dsw7@sfu.ca
# All functions needed for chain membership testing

import numpy as np

def get_adjacency_matrix(list_1, list_2):
    """
    DSW custom made adjacency matrix routine.
    Parameters:
        list_1, list_2 - the input edge lists, list-like
        i.e. list_1 = ['A', 'B', 'C', 'E', 'G']
             list_2 = ['D', 'D', 'C', 'F', 'F']
    Returns:
        adjMatrix: the adjacency matrix, numpy.ndarray type
    """

    # create symmetric lists
    list_u = list_1 + list_2
    list_v = list_2 + list_1
    
    # cast string list into array of unique int keys
    _, keys = np.unique(list_u + list_v, return_inverse=True)
    edge_u, edge_v = np.split(keys, 2)
    
    # find net number of nodes
    n = len(set(list_u + list_v))
     
    # adjacency matrix - initialize with 0
    adjMatrix = np.zeros((n, n)).astype(int)
    
    # scan the arrays edge_u and edge_v
    for i in range(len(edge_u)):
        u = edge_u[i]
        v = edge_v[i]
        adjMatrix[u][v] = 1
        
    return adjMatrix


def check_membership(A1, A2, B1, B2):
    """
    This function checks whether two networks of differing edge type
    share a common set of vertices.
    A, B, C, D are list like objects - for example:
        
        A1 = ['A', 'A']
        A2 = ['B', 'B']
        B1 = ['B', 'B']
        B2 = ['C', 'C']
        
    In this case, we have a network sharing a common vertex and of different
    edge identity:
        
        A -- B   B == C
        
    We want to test for common vertices.
    """
    # step 1 - make lists 'symmetric'
    endA = list(set(B1 + B2))
    endB = list(set(A1 + A2))
    A1_prime = A1 + endA
    A2_prime = A2 + endA
    B1_prime = B1 + endB
    B2_prime = B2 + endB
    
    """
    Here we modify:
        A1 = ['A', 'A']
        A2 = ['B', 'B']
        
        B1 = ['B', 'B']
        B2 = ['C', 'C']
    
    To:
           = ['A', 'A', 'B', 'C']
           = ['B', 'B', 'B', 'C']
        
           = ['B', 'B', 'A', 'B']
           = ['C', 'C', 'A', 'B']

    This equalizes the dimension/axes of both adjacency matrices.
    """
    
    # step 2 - get adjacencies of symmetries
    adjA = np.matrix(get_adjacency_matrix(A1_prime, A2_prime))
    adjB = np.matrix(get_adjacency_matrix(B1_prime, B2_prime))
    
    """
    We have:
        
    adjA:
        A B C
      A 0 1 0
      B 1 1 0
      C 0 0 1
     
    adjB:
        A B C
      A 1 0 0
      B 0 1 1
      C 0 1 0 
      
    Note that these share axes and dimension.
    """
    
    # step 3 - return diag((adjA)(adjB))
    """
    Now get the diagonal of the product of both matrices.
    In this case we have:
        A 0
        B 1
        C 0
    """
    diagonal_elements = np.diag(np.matmul(adjA, adjB))
    labels = sorted(list(set(A1 + A2 + B1 + B2)))
    dict_mapping = {a:b for a, b in zip(labels, diagonal_elements)}
    return dict_mapping