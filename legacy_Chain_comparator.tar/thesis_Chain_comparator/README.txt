** WARNING: I WILL DELETE THIS SOON **
** ALL SCRIPTS WILL BE AVAILABLE ON GITHUB **

* David *

TODO: replace soon with updated version
TODO: where the fuck is the testdir? -> Nevermind appears I ran tests and dumped results into this README

Thesis worthy directory for testing whether bridging interactions are 
superimposable with longer tyrosine/tryptophan chains.

Two options: 
	(A) main.py approach - a single PDB file can be analyzed in search of bridge/aromatic chain geometry
	(B) iterator.py approach - iterator over approximately 2600 PDB files known to contain both a bridge and a chain
	
IMPORTANT NOTE:
    (B) should NOT be published and should NOT be used for mining large databases. Argparsing a Python script is a very 
        "hacky" approach in this case - we are reimporting (i.e. executing) all libs 2600 times which is wastely.

How it works:

**  get_dlm.py was previously used to collect a .csv delimiter file that is used as an 
    import constraint in the exec.bat file.

 ____________           // files from metal / surface / bridge geometry study
|            | <------ ~/DATABASES/2018 Bridging Databases/AromaticChainsData_compressed.csv
| get_dlm.py | <------ ~/DATABASES/2018 Bridging Databases/GeometricData_compressed.csv
|____________|
      |
      |
       --> dlm.csv
             |
    	     |
    	      --> exec.bat // exec.bat passes lines in dlm.csv to the argparsed script iterator.py
    		      |    // exec.bat also executes the iterator.py script for each argparse arg
	              |
	  ($ py iterator.py PDB CODE) <-- imports from sys.path()
                      |
                      |
                       -->  output/1abc_.csv // output from iterator.py is dumped into ~/output

   ~/output
    	|
    	|
    	 --> prc.py // prc.py now analyses all files under output and generates a bar chart of counts
    		    |   // for different chain/bridge superimposition geometries
    	        |
    		     --> barchart.png

----------------------------------------------------------------------------------------------
Understanding output:

Our output file under output folder contains a total
of m x n lines, where there exist m number of chains in a file
and n number of bridges in a file.

Examples of data:

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
5o8h

Chains:  {52.0, 54.0, 6.0} // m = 1
Bridges: {52, 54}, {329, 6} // n = 2

3: Bridge {52, 54} member of larger chain {52.0, 54.0, 6.0}
4: One residue of bridge {329, 6} in larger chain {52.0, 54.0, 6.0}

2 total lines.

*********
5o8h - UPDATED BRIDGE COMPARATOR
CODE : INTERACTION TYPE : {BRIDGE} : {CHAIN} : EC CLASSIFIER 
5o8h : DS : {'TYR52', 'TYR54'} : {'TYR6', 'TYR52', 'TYR54'} : None 
5o8h : IS : {'TYR329', 'TYR6'} : {'TYR6', 'TYR52', 'TYR54'} : None 
*********

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
4col

Chains: {232.0, 267.0, 268.0, 270.0, 214.0}, 
        {546.0, 462.0, 527.0, 444.0, 542.0}, 
        {184.0, 185.0, 182.0, 247.0}, 
        {312.0, 601.0}, 
        {584.0, 237.0, 318.0}, 
        {203.0, 204.0}, 
        {81.0, 84.0, 87.0}, 
        {227.0, 622.0} // m = 8

Bridges: {435, 124} // n = 1

1: No relationship between chain {232.0, 267.0, 268.0, 270.0, 214.0} and bridge {435, 124}
1: No relationship between chain {546.0, 462.0, 527.0, 444.0, 542.0} and bridge {435, 124}
1: No relationship between chain {184.0, 185.0, 182.0, 247.0} and bridge {435, 124}
1: No relationship between chain {312.0, 601.0} and bridge {435, 124}
1: No relationship between chain {584.0, 237.0, 318.0} and bridge {435, 124}
1: No relationship between chain {203.0, 204.0} and bridge {435, 124}
1: No relationship between chain {81.0, 84.0, 87.0} and bridge {435, 124}
1: No relationship between chain {227.0, 622.0} and bridge {435, 124}

8 total lines.


*********
5 Bridges here instead of 1? -> yes because we are eliminating bridges where (A == PHE) || (B == PHE) 
4col - UPDATED
CODE : INTERACTION TYPE : {BRIDGE} : {CHAIN} : EC CLASSIFIER 
4col : NR : {'PHE512', 'TYR22'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 
4col : NR : {'TRP312', 'PHE280'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 

4col : NR : {'PHE512', 'TYR22'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'TRP312', 'PHE280'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'PHE512', 'TYR22'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'TRP312', 'PHE280'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'PHE512', 'TYR22'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'TRP312', 'PHE280'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'PHE512', 'TYR22'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'TRP312', 'PHE280'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'PHE512', 'TYR22'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'TRP312', 'PHE280'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'PHE512', 'TYR22'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'TRP312', 'PHE280'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'PHE512', 'TYR22'} : {'TRP312', 'TYR601'} : 1.17.4.2 
4col : IS : {'TRP312', 'PHE280'} : {'TRP312', 'TYR601'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP312', 'TYR601'} : 1.17.4.2 
4col : NR : {'PHE27', 'PHE11'} : {'TRP312', 'TYR601'} : 1.17.4.2 
4col : NR : {'TYR390', 'PHE469'} : {'TRP312', 'TYR601'} : 1.17.4.2 
*********

*********
// now we narrowed it down to 2 bridges which is still incorrect
// this introduced a new unknown bridge

// EXPLANATION: 

    data_retrieved = met_aromatic(CODE, 
                                  CHAIN=CHAIN, 
                                  CUTOFF=CUTOFF, 
                                  ANGLE=ANGLE, 
                                  MODEL=MODEL,
                                  filepath=path_to_file)
                                  
    # here we have found a Met429::{Phe126 / Tyr128 / Tyr424} 3-bridge                      
                                  
    data_retrieved = [d for d in data_retrieved if 'PHE' not in d]      
    
    # by removing the Phe we get Tyr128::Met429::Tyr424} 2-bridge
    # note that the degree of met is now 2
    # this means we are artificially picking up a 2-bridge as our algorithm sorts by MET degree in NetworkX

4col : NR : {'TYR435', 'TYR124'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP312', 'TYR601'} : 1.17.4.2 
4col : NR : {'TYR128', 'TYR424'} : {'TRP312', 'TYR601'} : 1.17.4.2 
*********


*********
Fixed: 
4col : NR : {'TYR435', 'TYR124'} : {'TRP527', 'TYR462', 'TYR542', 'TRP444', 'TRP546'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP182', 'TRP184', 'TYR185', 'TYR247'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR214', 'TYR232', 'TRP268', 'TYR267', 'TRP270'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP87', 'TYR84', 'TYR81'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR227', 'TYR622'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP203', 'TYR204'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TYR237', 'TYR584', 'TYR318'} : 1.17.4.2 
4col : NR : {'TYR435', 'TYR124'} : {'TRP312', 'TYR601'} : 1.17.4.2 
*********


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
3hk5

Chains: {178.0, 196.0}, 
        {325.0, 326.0, 364.0, 48.0, 50.0}, 
        {115.0, 79.0}, 
        {211.0, 155.0} // m = 4

Bridges: {155, 211} // n = 1

1: No relationship between chain {178.0, 196.0} and bridge {155, 211}
1: No relationship between chain {325.0, 326.0, 364.0, 48.0, 50.0} and bridge {155, 211}
1: No relationship between chain {115.0, 79.0} and bridge {155, 211}
2: Bridge {155, 211} collapses to 2-chain {211.0, 155.0}

4 total lines.

*********
3hk5 - UPDATED COMPARATOR
3hk5 : NR : {'TRP211', 'TRP155'} : {'TRP326', 'TYR48', 'TYR364', 'TYR50', 'TRP325'} : None 
3hk5 : NR : {'TRP211', 'TRP155'} : {'TRP79', 'TYR115'} : None 
3hk5 : PM : {'TRP211', 'TRP155'} : {'TRP211', 'TRP155'} : None 
3hk5 : NR : {'TRP211', 'TRP155'} : {'TRP196', 'TYR178'} : None 
*********

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1we1

Chains: {128.0, 50.0}, 
        {156.0, 87.0, 39.0}, 
        {92.0, 47.0} // m = 3

Bridges: {128, 50}, 
         {87, 39}, 
         {171, 125} // n = 3

2: Bridge {128, 50} collapses to 2-chain {128.0, 50.0}
1: No relationship between chain {128.0, 50.0} and bridge {87, 39}
1: No relationship between chain {128.0, 50.0} and bridge {171, 125}
1: No relationship between chain {156.0, 87.0, 39.0} and bridge {128, 50}
3: Bridge {87, 39} member of larger chain {156.0, 87.0, 39.0}
1: No relationship between chain {156.0, 87.0, 39.0} and bridge {171, 125}
1: No relationship between chain {92.0, 47.0} and bridge {128, 50}
1: No relationship between chain {92.0, 47.0} and bridge {87, 39}
1: No relationship between chain {92.0, 47.0} and bridge {171, 125}

9 total lines.

*********
3hk5 - UPDATED COMPARATOR
1we1 : NR : {'TYR39', 'TYR87'} : {'TRP92', 'TYR47'} : 1.14.99.3 
1we1 : NR : {'TYR50', 'TYR128'} : {'TRP92', 'TYR47'} : 1.14.99.3 
1we1 : NR : {'TYR171', 'TYR125'} : {'TRP92', 'TYR47'} : 1.14.99.3 
1we1 : NR : {'TYR39', 'TYR87'} : {'TYR50', 'TYR128'} : 1.14.99.3 
1we1 : PM : {'TYR50', 'TYR128'} : {'TYR50', 'TYR128'} : 1.14.99.3 
1we1 : NR : {'TYR171', 'TYR125'} : {'TYR50', 'TYR128'} : 1.14.99.3 
1we1 : DS : {'TYR39', 'TYR87'} : {'TYR39', 'TYR87', 'TYR156'} : 1.14.99.3 
1we1 : NR : {'TYR50', 'TYR128'} : {'TYR39', 'TYR87', 'TYR156'} : 1.14.99.3 
1we1 : NR : {'TYR171', 'TYR125'} : {'TYR39', 'TYR87', 'TYR156'} : 1.14.99.3 
*********

----------------------------------------------------------------------------------------------
Some other notes:

2602 out of 2611 successfully analyzed:

List of files not analyzed:
2xij  <-- ValueError: not enough values to unpack (expected 3, got 1)
4xtt  <-- SystemExit: No 2-bridges.
1pca  <-- ValueError: Cannot convert non-finite values (NA or inf) to integer
1jpg  <-- SystemExit: No 2-bridges.
3tyi  <-- SystemExit: CP: No Tyr/Trp::Met::Tyr/Trp bridges.
4gqv  <-- SystemExit: No Met-aromatic interactions. // might have inputted wrong pdb code
5yd9  <-- FileNotFoundError: [Errno 2] No such file or directory: 'C:\\Users\\David\\Desktop\\thesis_Chain_comparator\\pdb5yd9.ent'
1aye  <-- ValueError: Cannot convert non-finite values (NA or inf) to integer
3lhs  <-- SystemExit: No 2-bridges.


